package com.example.vinayak.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

public class WebViewActivity extends Activity {

    private WebView webView;
    String str;
    TextView tb;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.webview);
            tb = findViewById(R.id.textView);
        webView = (WebView) findViewById(R.id.webView1);
        WebSettings mWebSettings = webView.getSettings();
        mWebSettings.setJavaScriptEnabled(true);
        mWebSettings.setAllowFileAccess(true);
        mWebSettings.setDomStorageEnabled(true);
        mWebSettings.setPluginState(WebSettings.PluginState.ON);

        WebViewClient mWebViewClient = new WebViewClient();
        webView.setWebViewClient(mWebViewClient);
       // webView.getSettings().setJavaScriptEnabled(true);
        str = getIntent().getExtras().getString("text");
        tb.setText(str);

        webView.loadUrl(""+str+"");



    }

}
